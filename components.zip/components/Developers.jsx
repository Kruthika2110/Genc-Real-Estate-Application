import React, { Component } from 'react'

import DevelopersService from '../services/DevelopersService'
class Developers extends Component {
    constructor(props) {
        super(props)
      
        this.state = {
           developers:[]
           
        }
      }
      
      componentDidMount()
      {
          DevelopersService.getAllDevelopers().then((res) => {
           this.setState({developers: res.data})
           console.log(res.data)
           console.log('dev => ' + JSON.stringify(this.state.developers));
         })
      }
   
     render() {
       return (
         <div> 
            
             
          <h1> Developers</h1>
         
           <br/><br/>
          <div className='row'>
            <table className='table table-striped table-bordered'>
              <thead>
                <tr>
                  <td>name</td>
                  <td>mobile</td>
                  <td>email</td>
                  <td>City</td>
                </tr>
              </thead>
             <tbody>
               {
                 this.state.developers.map(
                   pro => {
                     <tr key={pro.devId}>
                     <td>{this.props.name}</td>
                     <td>{this.props.mobile}</td>
                     <td>{this.props.email}</td>
                     <td>{this.props.city}</td>
                     
                   </tr>
                   }
                  
                 )
               }
             </tbody>
            </table>
          </div>
           <br/><br/>
          
         </div>
       )
     }
}
export default Developers;



 