import axios from 'axios'
const url = "http://localhost:8095/api/v1/all";

class DevelopersService{
  
    getAllDevelopers()
    {
        return axios.get(url);
    }
}
export default new DevelopersService();