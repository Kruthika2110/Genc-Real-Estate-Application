package com.genc.entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Inheritance(strategy = InheritanceType.JOINED)
@Table(name="developers")
public class Developers {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int devId;
	private String name;
	@Column(unique = true)
	private String mobile;
	@Column(unique = true)
	private String email;
	private String city;
	
	
	public Developers() {
		super();
	}

	public Developers(String name, String mobile, String email, String city) {
		super();
		this.name = name;
		this.mobile = mobile;
		this.email = email;
		this.city = city;
		
	}

	public int getDevId() {
		return devId;
	}

	public void setDevId(int devId) {
		this.devId = devId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}


}
