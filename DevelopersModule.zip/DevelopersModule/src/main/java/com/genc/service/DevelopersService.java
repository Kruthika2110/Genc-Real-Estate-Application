package com.genc.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.genc.entity.Developers;


@Service
public interface DevelopersService {


	
	List<Developers> getAllUsers();
	
	Developers getUserById(int userId);
	
	
	Developers createUser(Developers user);
 
}
