package com.genc.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genc.Repository.DevelopersRepository;

import com.genc.entity.Developers;


@Service
public class DevelopersImpl implements DevelopersService {

	@Autowired
	private DevelopersRepository dDao;


	

	@Override
	public List<Developers> getAllUsers() {
		
		return dDao.findAll();
	}

	@Override
	public Developers getUserById(int userId) {
		return dDao.findById(userId).get();
	}

	@Override
	public Developers createUser(Developers developers) {
		// TODO Auto-generated method stub
		return dDao.save(developers);
	}

	
	

}