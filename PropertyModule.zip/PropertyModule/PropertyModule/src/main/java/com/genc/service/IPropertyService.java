package com.genc.service;

import java.util.List;

import com.genc.entity.Property;
import com.genc.exception.PropertyNotFoundException;
import com.genc.pojo.PropertyCriteria;

public interface IPropertyService {

	public Property addProperty(Property property);

	public Property editProperty(Property property);

	//public Property removeProperty(int propId) throws PropertyNotFoundException;

	public Property viewProperty(int propId) throws PropertyNotFoundException;

	public List<Property> listAllProperties();

	public List<Property> ListPropertyByCriteria(PropertyCriteria criteria);

}
