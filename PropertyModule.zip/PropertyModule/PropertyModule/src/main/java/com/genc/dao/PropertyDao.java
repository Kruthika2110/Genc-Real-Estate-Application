package com.genc.dao;

import java.util.List;

import com.genc.entity.Property;
import com.genc.pojo.PropertyCriteria;

public interface PropertyDao {


	public List<Property> fetchPropertyByCriteria(PropertyCriteria criteria);
}
