package com.genc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.genc.dao.PropertyDao;
import com.genc.entity.Property;
import com.genc.pojo.PropertyCriteria;

public interface PropertyRepository extends PropertyDao, JpaRepository<Property, Integer> {

	List<Property> fetchPropertyByCriteria(PropertyCriteria criteria);
	public List<Property> findByBrokerId(int brokerId);

}
